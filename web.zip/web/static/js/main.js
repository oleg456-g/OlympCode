// OlympCode — основной JS
